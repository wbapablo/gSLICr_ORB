//============================================================================
// Name        : imZED.cpp
// Author      :
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <stdio.h>
#include <string.h>
#include <ctime>
#include <chrono>
#include <cmath>
#include <time.h>
#include <stdlib.h>
#include <fstream>

#include "gSLICr_Lib/gSLICr.h"
#include "NVTimer.h"

#include <opencv2/opencv.hpp>

#include <zed/Camera.hpp>
#include <zed/utils/GlobalDefine.hpp>

#include <opencv2/features2d.hpp>
#include <opencv2/videoio.hpp>
#include <vector>
#include <iomanip>
#include <stddef.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <opencv2/cudaimgproc.hpp>
#include <opencv2/core/cuda.hpp>
#include <opencv2/cudafeatures2d.hpp>
#include <opencv2/cudafilters.hpp>
#include <opencv2/cudaarithm.hpp>
#include <opencv2/cudabgsegm.hpp>
#include <opencv2/cudacodec.hpp>
#include <opencv2/cudalegacy.hpp>
#include <opencv2/cudastereo.hpp>




#include <sstream>
#include <iostream>

#include <pcl/point_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/common/common_headers.h>
#include <pcl/visualization/cloud_viewer.h>

//New includes
#include <orb_func.hpp>
#include <func_sm.hpp>

using namespace gSLICr::objects;
using namespace gSLICr::engines;
using namespace gSLICr;
using namespace std;
using namespace cv;

void load_image(const Mat& inimg, gSLICr::UChar4Image* outimg)
{
	gSLICr::Vector4u* outimg_ptr = outimg->GetData(MEMORYDEVICE_CPU);

	for (int y = 0; y < outimg->noDims.y;y++)
		for (int x = 0; x < outimg->noDims.x; x++)
		{
			int idx = x + y * outimg->noDims.x;
			outimg_ptr[idx].b = inimg.at<Vec3b>(y, x)[0];
			outimg_ptr[idx].g = inimg.at<Vec3b>(y, x)[1];
			outimg_ptr[idx].r = inimg.at<Vec3b>(y, x)[2];
		}
}

void load_image(const gSLICr::UChar4Image* inimg, Mat& outimg)
{
	const gSLICr::Vector4u* inimg_ptr = inimg->GetData(MEMORYDEVICE_CPU);

	for (int y = 0; y < inimg->noDims.y; y++)
		for (int x = 0; x < inimg->noDims.x; x++)
		{
			int idx = x + y * inimg->noDims.x;
			outimg.at<Vec3b>(y, x)[0] = inimg_ptr[idx].b;
			outimg.at<Vec3b>(y, x)[1] = inimg_ptr[idx].g;
			outimg.at<Vec3b>(y, x)[2] = inimg_ptr[idx].r;
		}
}


int main(int argc, char **argv) {

    if (argc > 3) {
        return -1;
    }

    // Quick check input arguments
    bool readSVO = false;
    std::string SVOName;
    bool loadParams = false;
    std::string ParamsName;
    if (argc > 1) {
        std::string _arg;
        for (int i = 1; i < argc; i++) {
            _arg = argv[i];
            if (_arg.find(".svo") != std::string::npos) {
                // If a SVO is given we save its name
                readSVO = true;
                SVOName = _arg;
            }
            if (_arg.find(".ZEDinitParam") != std::string::npos) {
                // If a parameter file is given we save its name
                loadParams = true;
                ParamsName = _arg;
            }
        }
    }

    sl::zed::Camera* zed;

    if (!readSVO) // Live Mode
        zed = new sl::zed::Camera(sl::zed::VGA);
    else // SVO playback mode
        zed = new sl::zed::Camera(SVOName);

    // Define a struct of parameters for the initialization
    sl::zed::InitParams params;

    if (loadParams) // A parameters file was given in argument, we load it
        params.load(ParamsName);

    // Enables verbosity in the console
    params.verbose = true;


    sl::zed::ERRCODE err = zed->init(params);
    if (err != sl::zed::SUCCESS) {
        // Exit if an error occurred
        delete zed;
        return 1;
    }

    // Save the initialization parameters
    // The file can be used later in any zed based application
    params.save("MyParam");

    char key = ' ';


    int width_zed = zed->getImageSize().width;
    int height_zed = zed->getImageSize().height;


    //FOR THE ORB TO FIND THE POINTS
    cv::Mat ileft(height_zed, width_zed, CV_64FC1);
    cv::Mat iright(height_zed, width_zed, CV_64FC1);
    cv::Mat iconc(height_zed, 2*width_zed, CV_64FC1);

    //CAMERA OUTPUT
    cv::Mat ileft4(height_zed, width_zed, CV_64FC4);
    cv::Mat iright4(height_zed, width_zed, CV_64FC4);
    cv::Mat iconc4(height_zed, 2*width_zed, CV_64FC4);
    //FOR gSLICr we need to change the size to the correct VGA dimensions
    cv::Mat ileft3(height_zed, width_zed, CV_64FC3);
    cv::Mat iright3(height_zed, width_zed, CV_64FC3);
    cv::Mat iconc3(height_zed, 2*width_zed, CV_64FC3);

    vector<KeyPoint> kpts_1,kpts_2;
    vector<DMatch> good_matches;

    //Undistorted Points
    vector<Point2f> undistL, undistR;
    //Distorted Points
    vector<Point2f> distL, distR;

    //Inverse Calibration
    Mat mCMlInv,mCMrInv;
    Mat mcMl,mcMr,mcDl,mcDr;

    //undistorted points output
    vector<Point3f> stereoPoints;


    pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZRGB>);

    //planes output
    pcl::PointCloud<pcl::PointXYZRGB>::Ptr result (new pcl::PointCloud<pcl::PointXYZRGB>);
    pcl::PointCloud<pcl::PointXYZRGB>::Ptr result1 (new pcl::PointCloud<pcl::PointXYZRGB>);
    pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud_temp (new pcl::PointCloud<pcl::PointXYZRGB>);

    vector<pcl::PointCloud<pcl::PointXYZRGB>::Ptr> all_clouds;


    pcl::visualization::CloudViewer viewer ("Simple Viewer");

    cv::Size displaySize(2*672, 376);

    sl::zed::SENSING_MODE dm_type = sl::zed::STANDARD;

    cv::namedWindow("VIEW", cv::WINDOW_AUTOSIZE);

    std::cout << "Press 'q' to exit" << std::endl;

    // Jetson only. Execute the calling thread on core 2
    //sl::zed::Camera::sticktoCPUCore(2);

    //////////////////////////////gSLICr////////////////////////////////////
	// gSLICr settings
	gSLICr::objects::settings my_settings;
	my_settings.img_size.x = 640;
	my_settings.img_size.y = 480;
	my_settings.no_segs = 30;
	my_settings.spixel_size = 32;//32 funciona
	my_settings.coh_weight = 2.0f;
	my_settings.no_iters = 6;
	my_settings.color_space = gSLICr::CIELAB; // gSLICr::CIELAB for Lab, or gSLICr::RGB for RGB
	my_settings.seg_method = gSLICr::GIVEN_NUM; // or gSLICr::GIVEN_NUM for given number GIVEN_SIZE
	my_settings.do_enforce_connectivity = false; // whether or not run the enforce connectivity step


	// instantiate a core_engine
	gSLICr::engines::core_engine* gSLICr_engine = new gSLICr::engines::core_engine(my_settings);

	int spixel_size = my_settings.spixel_size;

	int width  = my_settings.img_size.x;
	int height = my_settings.img_size.y;
	//am_sz is the number of superpixels


	//im_sz tamaño de la imagen
	int im_sz = width*height;

	// gSLICr takes gSLICr::UChar4Image as input and out put
	gSLICr::UChar4Image* in_img = new gSLICr::UChar4Image(my_settings.img_size, true, true);
	gSLICr::UChar4Image* out_img = new gSLICr::UChar4Image(my_settings.img_size, true, true);

	Size s(my_settings.img_size.x, my_settings.img_size.y);
	Mat frame(Size(width,height),CV_64FC3);
	Mat boundry_draw_frame; boundry_draw_frame.create(s, CV_8UC3);
	Mat labels;
    Mat frame2(Size(width,height),CV_8UC3);
    Mat frame2lab(Size(width,height),CV_8UC3);
    Mat fr_lab(Size(width,height),CV_8UC3);
    StopWatchInterface *my_timer; sdkCreateTimer(&my_timer);
    //Reserve memory space for labels m*n
    const gSLICr::IntImage* Idx_im;

    const int* data_ptr;

    //cv::namedWindow("SLIC prueba", WINDOW_AUTOSIZE);

	ofstream lol;


    //CONNECTIONS
    vector<vector<int>> conn_com;
    vector<int> kxy;
    vector<int> kr;
    vector<int> kg;
    vector<int> kb;
    vector<vector<int>> tails;
	vector<double> avg_r;
	vector<double> avg_g;
	vector<double> avg_b;

	vector<int> pcl_sp_idx;

	//int sel=0;

    int group;

    int n_sp;

    ////////////////////////////////////////////////////////////////////////

    // Loop until 'q' is pressed
    while ((key != 'q' )) {
        // Disparity Map filtering

        // Get frames and launch the computation
        zed->grab(dm_type,false, false, false);

        slMat2cvMat(zed->retrieveImage(sl::zed::LEFT_UNRECTIFIED)).copyTo(ileft4);
        slMat2cvMat(zed->retrieveImage(sl::zed::RIGHT_UNRECTIFIED)).copyTo(iright4);



        cvtColor(ileft4, ileft3,CV_RGBA2RGB);
        cvtColor(iright4, iright3,CV_RGBA2RGB);




        cvtColor(ileft4, ileft,CV_RGBA2GRAY);
        cvtColor(iright4, iright,CV_RGBA2GRAY);

        resize(ileft3, frame,s); // gSLICr

        cvtColor(frame, frame,CV_RGB2Lab);


        load_image(frame, in_img); // gSLICr

		gSLICr_engine->Process_Frame(in_img);

        gSLICr_engine->Draw_Segmentation_Result(out_img);
     //LABELS
        Idx_im = gSLICr_engine->Get_Seg_Res();

        data_ptr = Idx_im->GetData(MEMORYDEVICE_CPU);
        //n_sp:: quantity of superpixels
        n_sp = data_ptr[im_sz-1]+1;

        create_connection_ref_mat(conn_com, n_sp);

        vector<vector<int>> fillmat (n_sp);
    	vector<vector<int>> col_r	(n_sp);
    	vector<vector<int>> col_g	(n_sp);
    	vector<vector<int>> col_b	(n_sp);
    	//kxy are the centroids
        find_sp_coordinates(data_ptr, im_sz, kxy, fillmat,frame,col_r,col_g,col_b);


		//Fill zeros the adj mattrix
		Mat m_ad = Mat(n_sp,n_sp, CV_64F,cvScalar(0));
		create_adj_mat(data_ptr,m_ad);

		//In col_r,g,b Outs the super-pixels average at kr,kg,kb
		extract_colours(kr, kg, kb, col_r,col_g,col_b);

		fill_connection_mat2(m_ad, conn_com, tails, data_ptr, n_sp,group,kr,kg, kb, avg_r, avg_g, avg_b);

		//Color promedio del grupo o aglomeración de SuperPixeles
		//avg_t,g,b


		//cout<<"2 "<<avg_r.size() <<endl;
		//sdkResetTimer(&my_timer); sdkStartTimer(&my_timer);
		fill_tool(frame2, tails, data_ptr, height, width, avg_r, avg_g, avg_b,fillmat);
		//sdkStopTimer(&my_timer);
		//cout<<"\rsegmentation in:["<<sdkGetTimerValue(&my_timer)<<"]ms"<<flush;


		cv::cuda::GpuMat img1(ileft);
		cv::cuda::GpuMat img2(iright);
		cv::cuda::GpuMat img3(iconc);


		compute_orb(img1, img2, kpts_1, kpts_2, good_matches);


		//undistortion, this function takes the distorted points as the input and
		// undistort them into the vector
		depth_undistort(kpts_1,kpts_2,good_matches,undistL,undistR,mCMlInv,mCMrInv,distL,distR,mcMl,mcMr,mcDl,mcDr);
		int noAGL= tails.size();//300
		//cout <<"noAGL "<<noAGL<<endl;
		vector<vector<int>> pcl_AGL_idx (noAGL);

		compute_depth(mCMlInv,mCMrInv,undistL,undistR,stereoPoints,distL,cloud,ileft3,data_ptr,conn_com,pcl_sp_idx,pcl_AGL_idx); //line intersection method


		cv::drawMatches(ileft3, kpts_1, iright3, kpts_2, good_matches, iconc3);
		good_matches.clear();




            /*if(key == 'a'){
            	sel =+ 1;
            	if (sel >= (group-2)){
            		sel=group-2;
            	}

            }else if(key == 's'){
            	sel =- 1;
            	if (sel<=0){
            		sel=0;
            	}
            }*/



		for(int ki=0; ki< noAGL; ki++){


			 // Fill in the cloud data
			cloud_temp->width    = pcl_AGL_idx[ki].size();
			cloud_temp->height   = 1;
			cloud_temp->is_dense = true;
			cloud_temp->points.resize (cloud_temp->width * cloud_temp->height);

			if((cloud_temp->width)>2 ){
				for(int i=0; i<pcl_AGL_idx[ki].size(); i++ ){
					int i2=pcl_AGL_idx[ki][i];
					cloud_temp->points[i]=cloud->points[i2];
				}
				all_clouds.push_back(cloud_temp);

			}


		}
          // cout<<"nubes : "<< all_clouds.size() << endl;
            //cout<< cloud->points.size() << endl;

		if(cloud->points.size()>20){
			planextraction(cloud,result);
			out_data(result);
		}else{
			//cout<<"plane can't be detected"<<endl;
		}

		//cout << "Puntos: " << cloud->points.size() << endl;

		//cout<<"plane 2"<<endl;
		if(cloud->points.size()>50){
			planextraction(cloud,result1);
			out_data(result1);
		}else{
			//cout<<"plane can't be detected"<<endl;
		}

		viewer.showCloud(result);
		pcl_AGL_idx.clear();



        cvtColor(frame2, frame2lab,CV_Lab2RGB);
        imshow("SLIC prueba", frame2lab);

        imshow("VIEW", iconc3);




        //Clean All
        fillmat.clear();
        conn_com.clear();
        tails.clear();
        kxy.clear();
        kr.clear();
        kg.clear();
        kb.clear();
       	avg_r.clear();
       	avg_g.clear();
       	avg_b.clear();
       	col_b.clear();
       	col_g.clear();
       	col_r.clear();


       	pcl_sp_idx.clear();

        undistL.clear();
        undistR.clear();
        distR.clear();
        distL.clear();
        stereoPoints.clear();

        kpts_1.clear();
        kpts_2.clear();

        all_clouds.clear();

        key = cv::waitKey(5);
    }


    delete zed;
    return 0;
}


