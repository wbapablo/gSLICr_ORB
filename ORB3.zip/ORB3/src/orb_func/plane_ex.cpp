
#include <opencv2/features2d.hpp>
#include <opencv2/videoio.hpp>
#include <vector>
#include <iomanip>
#include <stddef.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <opencv2/cudaimgproc.hpp>
#include <opencv2/core/cuda.hpp>
#include <opencv2/cudafeatures2d.hpp>
#include <opencv2/cudafilters.hpp>
#include <opencv2/cudaarithm.hpp>
#include <opencv2/cudabgsegm.hpp>
#include <opencv2/cudacodec.hpp>
#include <opencv2/cudalegacy.hpp>
#include <opencv2/cudastereo.hpp>

#include <pcl/point_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/common/common_headers.h>
#include <pcl/visualization/cloud_viewer.h>


void planextraction(pcl::PointCloud<pcl::PointXYZRGB>::Ptr& cloud,pcl::PointCloud<pcl::PointXYZRGB>::Ptr& result){
	//create cloud data
	  pcl::PointIndices::Ptr inliers_ransac_b (new pcl::PointIndices);
	  pcl::ModelCoefficients::Ptr coefficients (new pcl::ModelCoefficients);
	  pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud_f (new pcl::PointCloud<pcl::PointXYZRGB>);

	  pcl::SACSegmentation<pcl::PointXYZRGB> seg;
	  // Optional

	  seg.setOptimizeCoefficients (true);
	  // Mandatory
	  seg.setModelType (pcl::SACMODEL_PLANE);
	  seg.setMethodType (pcl::SAC_RANSAC);
	  seg.setMaxIterations(200);
	  seg.setDistanceThreshold (5);//0.06 //3.58

	  // Create the filtering object
	  pcl::ExtractIndices<pcl::PointXYZRGB> extract;

	  seg.setInputCloud (cloud);
	  seg.segment (*inliers_ransac_b, *coefficients);

	  extract.setInputCloud (cloud);
	  extract.setIndices (inliers_ransac_b);
	  extract.setNegative (false);
	  extract.filter (*result);

	  extract.setNegative (true);
	  extract.filter (*cloud_f);
	  cloud.swap (cloud_f);
}
