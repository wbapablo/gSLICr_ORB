#include <math.h>

#include <opencv2/features2d.hpp>
#include <opencv2/videoio.hpp>
#include <vector>
#include <iomanip>
#include <stddef.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <opencv2/cudaimgproc.hpp>
#include <opencv2/core/cuda.hpp>
#include <opencv2/cudafeatures2d.hpp>
#include <opencv2/cudafilters.hpp>
#include <opencv2/cudaarithm.hpp>
#include <opencv2/cudabgsegm.hpp>
#include <opencv2/cudacodec.hpp>
#include <opencv2/cudalegacy.hpp>
#include <opencv2/cudastereo.hpp>


using namespace std;
using namespace cv;

void undistortImagePointTordoff(
	Point2f &undistortedImgPoint,
	Point2f &distortedImgPoint,
	Point2f principlePoint,
		double k1,
		double k2,
		double p1,
		double p2,
		double k3,
		Point2f df);

void depth_undistort(vector<KeyPoint> kpts_1,vector<KeyPoint> kpts_2,vector<DMatch> good_matches, vector<Point2f>& undistortL,vector<Point2f>& undistortR,
					 Mat& mCMlInv, Mat& mCMrInv,vector<Point2f>& distortL, vector<Point2f>& distortR, Mat& mcMl,Mat& mcMr, Mat& mcDl, Mat& mcDr){
	//***************************** read calibration

	//undistortL.clear();
	//undistortR.clear();


	FileStorage cl("camera_config/ZED_L.yaml", FileStorage::READ);

	cl["CM"]>> mcMl;
	cl["D"]>> mcDl;
	//std::cout<<"matrix K: "<<mcMl<< std::endl;
	cl.release();
	mCMlInv=mcMl.inv();
	FileStorage cr("camera_config/ZED_R.yaml", FileStorage::READ);
    //CM es la matriz 3x3
	cr["CM"]>> mcMr;
	//D son los parámetros de distorsión k1, k2, p1, p2, k3
	cr["D"]>> mcDr;
	cr.release();
	mCMrInv=mcMr.inv();
	//*******************************
	Point2f d_kpts_l, d_kpts_r;
	Point2f d_kpts_Ul, d_kpts_Ur;

	Point2f principalPtL, principalPtR;

	double coeffL, coeffR;

	Point2f dfl,dfr;
	double k1l,k2l,p1l,p2l,k3l;
	double k1r,k2r,p1r,p2r,k3r;
	//		[0]		[1]		[2]
	//[0]	fx	-	0	-	PPtx
	//[1]	0	-	fy	-	PPty
	//[2]	0	-	0	-	1

	k1l=mcDl.at<double>(0,0);
	k2l=mcDl.at<double>(0,1);
	p1l=mcDl.at<double>(0,2);
	p2l=mcDl.at<double>(0,3);
	k3l=mcDl.at<double>(0,4);

	k1r=mcDr.at<double>(0,0);
	k2r=mcDr.at<double>(0,1);
	p1r=mcDr.at<double>(0,2);
	p2r=mcDr.at<double>(0,3);
	k3r=mcDr.at<double>(0,4);

	dfl.x = mcMl.at<double>(0,0);
	dfl.y = mcMl.at<double>(1,1);

	dfr.x = mcMr.at<double>(0,0);
	dfr.y = mcMr.at<double>(1,1);

	principalPtL.x = mcMl.at<double>(0,2);
	principalPtL.y = mcMl.at<double>(1,2);

	principalPtR.x = mcMr.at<double>(0,2);
	principalPtR.y = mcMr.at<double>(1,2);

	for (int k=0; k < good_matches.size(); k++){

			d_kpts_l.x=kpts_1[good_matches[k].queryIdx].pt.x;//U
			d_kpts_l.y=kpts_1[good_matches[k].queryIdx].pt.y;//V

			undistortImagePointTordoff(d_kpts_Ul,d_kpts_l,principalPtL,k1l,k2l,p1l,p2l,k3l,dfl);

			d_kpts_r.x=kpts_2[good_matches[k].trainIdx].pt.x;//V
			d_kpts_r.y=kpts_2[good_matches[k].trainIdx].pt.y;



			undistortImagePointTordoff(d_kpts_Ur,d_kpts_r,principalPtR,k1r,k2r,p1r,p2r,k3r,dfr);


			double dispX,dispY;

			dispX = d_kpts_Ul.x-d_kpts_Ur.x;
			dispY = d_kpts_Ul.y-d_kpts_Ur.y;

			if ((dispX>0)&&(dispY<5)&&(dispY>-5) ){
				undistortL.push_back(d_kpts_Ul);
				distortL.push_back(d_kpts_l);

				undistortR.push_back(d_kpts_Ur);
				distortR.push_back(d_kpts_r);
			}

	}
}


void undistortImagePointTordoff(
	Point2f &undistortedImgPoint,
	Point2f &distortedImgPoint,
	Point2f principalPoint,
	double k1,
	double k2,
	double p1,
	double p2,
	double k3,
	Point2f df){

	double xp=(distortedImgPoint.x-principalPoint.x)/df.x;
	double yp=(distortedImgPoint.y-principalPoint.y)/df.y;

	double rsq=pow(xp,2)+pow(yp,2);

	double num  =  1 +  k1*rsq  +  k2*pow(rsq,2)  +  k3*pow(rsq,4);
	double den  =  1 +  k3*(rsq +     pow(rsq,2)  +     pow(rsq,4));

	double xpp = xp*num/den + 2*p1*xp*yp   +  p2*(rsq+2*pow(xp,2));
	double ypp = yp*num/den + p1*(rsq+2*pow(yp,2))+     2*p2*xp*yp;

	undistortedImgPoint.x = df.x * xpp + principalPoint.x;
	undistortedImgPoint.y = df.y * ypp + principalPoint.y;
}
