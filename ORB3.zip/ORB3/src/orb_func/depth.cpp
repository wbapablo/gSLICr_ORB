
#include <opencv2/features2d.hpp>
#include <opencv2/videoio.hpp>
#include <vector>
#include <iomanip>
#include <stddef.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <opencv2/cudaimgproc.hpp>
#include <opencv2/core/cuda.hpp>
#include <opencv2/cudafeatures2d.hpp>
#include <opencv2/cudafilters.hpp>
#include <opencv2/cudaarithm.hpp>
#include <opencv2/cudabgsegm.hpp>
#include <opencv2/cudacodec.hpp>
#include <opencv2/cudalegacy.hpp>
#include <opencv2/cudastereo.hpp>

#include <pcl/point_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/common/common_headers.h>
#include <pcl/visualization/cloud_viewer.h>

using namespace std;
using namespace cv;


void lineIntersection(double x1, double y1, double x2, double y2,
					  double x3, double y3, double x4, double y4,
					  double& px, double&);

void compute_depth(Mat 								mCMlInv,
		Mat 										mCMrInv,
		vector<Point2f> 							undistortL,
		vector<Point2f> 							undistortR,
		vector<Point3f>& 							stereoPoints,
		vector<Point2f> 							distortL,
		pcl::PointCloud<pcl::PointXYZRGB>::Ptr& 	cloud,
		cv::Mat& 									img,
		const int* 									klabels,
		vector<vector<int>> 						conn_mat,
		vector<int>& 								pcl_sp_idx,
		vector<vector<int>>& 								pcl_AGL_idx
		)
	{

	//************ calibration files*************
	Mat mF,mR,mT;
	Mat mRwc,mTwc;
	FileStorage cf("camera_config/stereo.yaml", FileStorage::READ);
    ////printjmcv(cf.isOpened());
	cf["F"]>> mF;
	cf["R"]>> mR;
	cf["T"]>> mT;
	cf.release();


	mRwc = mR.inv();
	mTwc = -mRwc*mT;
	//*******************************************

	 // Fill in the cloud data
  cloud->width    = undistortL.size();
  cloud->height   = 1;
  cloud->is_dense = true;
  cloud->points.resize (cloud->width * cloud->height);

  int xypcl;
  int sp,AGL;

	for (int i=0; i< undistortL.size(); i++){

		Point3d u(undistortL[i].x, undistortL[i].y, 1.0);

		Mat_<double> um = mCMlInv * Mat_<double>(u);
		//cout << "um: " << u.x << endl;
		u.x = um(0,0);
		u.y = um(1,0);
		u.z = um(2,0);

		Point3d v(undistortR[i].x, undistortR[i].y, 1.0);

		Mat_<double> vm = mCMrInv * Mat_<double>(v);
		v.x = vm(0,0);
		v.y = vm(1,0);
		v.z = vm(2,0);

		//printjmcv(vm);
		vm = mRwc * Mat_<double>(v) + mTwc;
		v.x = vm(0,0);
		v.y = vm(1,0);
		v.z = vm(2,0);
		//printjmcv(vm);
		//cout <<"Izq: " << u.x << "  Der: " << v.x<< endl;

		double x1 = 0;
		double y1 = 0;
		double x2 = u.x;
		double y2 = u.z;

		double x3 = mTwc.at<double>(0);
		double y3 = mTwc.at<double>(2);
		double x4 = v.x;
		double y4 = v.z;

		double px,py;

		lineIntersection(x1,y1,x2,y2,
						 x3,y3,x4,y4,
						 px,py);

		//It's desired dispX to be greater than 0
		//and dispY close to 0

		double depth=py;
		Point3f pointsWC;
		pointsWC.x=undistortL[i].x;
		pointsWC.y=undistortL[i].y;
		pointsWC.z=depth;

		stereoPoints.push_back(pointsWC);

		cloud->points[i].x = undistortL[i].x;
		cloud->points[i].y = undistortL[i].y;
		cloud->points[i].z = depth;


		cloud->points[i].r = img.at<Vec3b>(distortL[i].x,distortL[i].y)[2];
		cloud->points[i].g = img.at<Vec3b>(distortL[i].x,distortL[i].y)[1];
		cloud->points[i].b = img.at<Vec3b>(distortL[i].x,distortL[i].y)[0];


		xypcl= int(undistortL[i].x + 640*undistortL[i].y);
		sp = klabels[xypcl];
		pcl_sp_idx.push_back(sp);
		AGL = conn_mat[sp][2];

		//En cada renglon de pcl_AGL estarán todos los puntos nubes correspondientes a dicho AGL
		pcl_AGL_idx[AGL].push_back(i);



	}



}



void lineIntersection(double x1, double y1, double x2, double y2,
					  double x3, double y3, double x4, double y4,
					  double &px, double &py)
{
	double denom = (x1-x2)*(y3-y4) - (y1-y2)*(x3-x4);

	if(denom < 0.0001)
	{
		px = 0;
		py = 0;
		return ;
	}

	px = (x1*y2-y1*x2)*(x3-x4)-(x1-x2)*(x3*y4-y3*x4);

	px = px/denom;

	py = (x1*y2-y1*x2)*(y3-y4)-(y1-y2)*(x3*y4-y3*x4);

	py = py/denom;
}

