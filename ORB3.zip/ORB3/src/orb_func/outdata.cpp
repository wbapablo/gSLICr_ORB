
#include <opencv2/features2d.hpp>
#include <opencv2/videoio.hpp>
#include <vector>
#include <iomanip>
#include <stddef.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>



#include <pcl/point_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/common/common_headers.h>
#include <pcl/visualization/cloud_viewer.h>

using namespace std;
using namespace cv;

void out_data(pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud){
	int aux=0;
	int sz=cloud->points.size();
	for(int i=0;i<cloud->points.size();i++){
		aux+=cloud->points[i].z;
		}
	//cout<<"depth mean= "<<aux/sz<<endl;

	Mat data_pts = Mat(sz,2,CV_64FC1);

	for (int j=0;j<data_pts.rows;j++){
		data_pts.at<double>(j,0)=cloud->points[j].x;
		data_pts.at<double>(j,1)=cloud->points[j].y;
		}
	PCA pca_analysis(data_pts,Mat(),CV_PCA_DATA_AS_ROW);

	vector<Point2d> eigen_vecs(2);
	vector<double> eigen_val(2);

	for(int k=0;k<2;k++){
		eigen_vecs[k]=Point2d(pca_analysis.eigenvectors.at<double>(k,0),
							  pca_analysis.eigenvectors.at<double>(k,1));

		eigen_val[k]= pca_analysis.eigenvalues.at<double>(0,k);

		}

	//cout<<"eigenvectors= "<<eigen_vecs<<endl;
	//printf("eigenvalues= %f,%f \n",eigen_val[0],eigen_val[1]);


	eigen_vecs.clear();
	eigen_val.clear();
}
