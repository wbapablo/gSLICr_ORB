#include <vector>



using namespace std;
using namespace cv;

void compute_orb(cuda::GpuMat 	img1,
		cuda::GpuMat 			img2,
		vector<KeyPoint>& 		kpts_1,
		vector<KeyPoint>& 		kpts_2,
		vector<DMatch>& 		good_matches);


void depth_undistort(vector<KeyPoint> 		kpts_1,
		vector<KeyPoint> 					kpts_2,
		vector<DMatch> 						good_matches,
		vector<Point2f>&					undistortL,
		vector<Point2f>& 					undistortR,
					 Mat& 					mCMlInv,
					 Mat& 					mCMrInv,
					 vector<Point2f>& 		distortL,
					 vector<Point2f>& 		distortR,
					 Mat& 					mcMl,
					 Mat& 					mcMr,
					 Mat& 					mcDl,
					 Mat& 					mcDr);


void compute_depth(Mat			 mCMlInv,
		Mat						 mCMrInv,
		vector<Point2f>			 undistortL,
		vector<Point2f>			 undistortR,
		vector<Point3f>&		 stereoPoints,
		vector<Point2f>			 distortL,
		pcl::PointCloud<pcl::PointXYZRGB>::Ptr& cloud,
		cv::Mat& img,
		const int* 									klabels,
		vector<vector<int>> 						conn_mat,
		vector<int>& 								pcl_sp_idx,
		vector<vector<int>>& 								pcl_AGL_idx);


void planextraction(pcl::PointCloud<pcl::PointXYZRGB>::Ptr& cloud,pcl::PointCloud<pcl::PointXYZRGB>::Ptr& result);


void out_data(pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud);
