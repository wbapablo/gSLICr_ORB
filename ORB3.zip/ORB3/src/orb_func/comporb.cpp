
#include <opencv2/features2d.hpp>
#include <opencv2/videoio.hpp>
#include <vector>
#include <iomanip>
#include <stddef.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <opencv2/cudaimgproc.hpp>
#include <opencv2/core/cuda.hpp>
#include <opencv2/cudafeatures2d.hpp>
#include <opencv2/cudafilters.hpp>
#include <opencv2/cudaarithm.hpp>
#include <opencv2/cudabgsegm.hpp>
#include <opencv2/cudacodec.hpp>
#include <opencv2/cudalegacy.hpp>
#include <opencv2/cudastereo.hpp>


using namespace std;
using namespace cv;



void compute_orb(cuda::GpuMat img1, cuda::GpuMat img2, vector<KeyPoint>& kpts_1, vector<KeyPoint>& kpts_2, vector<DMatch>& good_matches){
	//std::vector<cv::KeyPoint> keypoints1, keypoints2;
	cv::cuda::GpuMat keypoints1, keypoints2;
	cv::cuda::GpuMat descriptors1, descriptors2;
	cv::Ptr<cuda::ORB> d_orb = cuda::ORB::create(1500,1.2,8,31,0,2,ORB::HARRIS_SCORE,31,20,true);
	//good_matches.clear();

	d_orb->detectAndComputeAsync(img1, cv::cuda::GpuMat(), keypoints1, descriptors1);
	d_orb->detectAndComputeAsync(img2, cv::cuda::GpuMat(), keypoints2, descriptors2);

	Ptr<cuda::DescriptorMatcher> matcher = cv::cuda::DescriptorMatcher::createBFMatcher(NORM_HAMMING);
	//cv::BFMatcher matcher(NORM_HAMMING);
	std::vector<std::vector<DMatch>> matches;
	matcher->knnMatch(descriptors1, descriptors2, matches, 2, cv::cuda::GpuMat());


	for(int k=0; k < min(descriptors1.rows-1, (int)matches.size()); k++){
		if((matches[k][0].distance<0.5*(matches[k][1].distance)) && ((int)matches[k].size()<=2 &&(int)matches[k].size()>0)){
			good_matches.push_back(matches[k][0]);  ;
		}
	}
	d_orb->convert(keypoints1, kpts_1);
	d_orb->convert(keypoints2, kpts_2);

	matches.clear();

}
