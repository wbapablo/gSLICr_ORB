#include <time.h>
#include <stdio.h>
#include <vector>
#include <math.h>

#include "opencv2/highgui/highgui.hpp"
#include "opencv2/core/core.hpp"
#include "opencv2/opencv.hpp"

using namespace std;
using namespace cv;


//INS
//connection matrix empty | image | labels | group index |
//
//
//OUTS
// tails | group index
//
void fill_connection_mat2(
		Mat						    ad_mat,//cambiar el formato
		vector<vector<int>>& 		conexiones,
		vector<vector<int>>& 		tails,
		const int* 					klabels,
		int& 						sz,
		int& 						group_i,
		vector<int> 				kr,//l
		vector<int>					kg,//a
		vector<int>					kb,//b
		vector<double>&				avg_r,
		vector<double>&				avg_g,
		vector<double>&				avg_b
		)
{

	float d_r, d_g, d_b;
	double color_d;
	int v_son;
	int th=14;
	group_i=0;

	int x,y;

	float wr=1.5;
	float wg=1;
	float wb=0.9;

	int run;


	int a_r=0,a_g=0,a_b=0,colcont=0;
	int prom;


	//Checar TODOS los super pixeles
	for(int ic=0; ic < sz; ic++){
		if(conexiones[ic][1]==0){
			conexiones[ic][1]=1;
			conexiones[ic][2]=group_i;
			vector<int> temp;
			//Cada vector Temp contará con todos los integrantes de cada grupo
			// conexiones[ic][0] es el primer padre de cada grupo
			// krkgkb contiene  los colores de los super-pixeles, sus indices son los numeros de superpixeles
			temp.push_back(conexiones[ic][0]);
			a_r=kr[conexiones[ic][0]];
			colcont++;
			a_g=kg[conexiones[ic][0]];
			a_b=kb[conexiones[ic][0]];

			for(int ic2=0; ic2 < temp.size() ; ic2++){
				//En y estoy tomando el último elemento del temp que en cada ciclo es el padre y de él me anclo para analizar a los hijos
				y=temp[ic2];
				run=sz-y;
				for(int ic3=1; ic3<=run;ic3++){

					x=y+ic3;
					/*
					if(x>=(sz-1)){
						x=(sz-1);
					}*/

						// Checar si es adyacente y si no está visitado ya
					if((ad_mat.at<int>(y,x)==1)&&(conexiones[x][1]==0)){

						d_r=wr*(kr[y]-kr[x]);
						d_g=wg*(kg[y]-kg[x]);
						d_b=wb*(kb[y]-kb[x]);

						color_d=sqrt(pow(d_r,2) + pow(d_g,2) + pow(d_b,2));

						//cout<<kr[y]<<endl;
						if (color_d<th){
						//if ((d_r<th)&&(d_g<th)&&(d_b<th)){
							v_son = x;
							temp.push_back(v_son);
							a_r += kr[v_son];
						    colcont++;
							a_g += kg[v_son];
							a_b += kb[v_son];
							conexiones[v_son][1]=1;
							conexiones[v_son][2]=group_i;
						}
					}



				}

			}
			tails.push_back(temp);
			group_i++;
			prom=a_r/colcont;
			avg_r.push_back(prom);
			prom=a_g/colcont;
			avg_g.push_back(prom);
			prom=a_b/colcont;
			avg_b.push_back(prom);
			colcont=0,a_r=0,a_g=0,a_b=0;

		}
	}



}
