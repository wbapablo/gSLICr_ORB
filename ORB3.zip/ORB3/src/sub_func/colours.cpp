#include <time.h>
#include <stdio.h>
#include <vector>
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/core/core.hpp"
#include "opencv2/opencv.hpp"
#include <math.h>

using namespace std;
using namespace cv;

void extract_colours(

		vector<int>& 	kr,
		vector<int>&	kg,
		vector<int>&	kb,
		vector<vector<int>> col_r,
		vector<vector<int>> col_g,
		vector<vector<int>> col_b
		)
{
	int sz=col_r.size();
	double prom;
	//cout << sz <<endl;

	for (int i=0; i<sz; i++){
		int ar=0,ag=0,ab=0;
		int div=col_r[i].size();
		if(div<=0){
			cout<<"DASDASDAS"<<endl;
		}

		for(int j=0; j<div ; j++){
			ab=ab+col_b[i][j];
			ag=ag+col_g[i][j];
			ar=ar+col_r[i][j];
		}

		prom=ab/div;

		kb.push_back(prom);
		prom=ag/div;
		kg.push_back(prom);
		prom=ar/div;
		kr.push_back(prom);


	}
}
