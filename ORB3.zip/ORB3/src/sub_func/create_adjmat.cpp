

#include <time.h>
#include <stdio.h>


#include "opencv2/highgui/highgui.hpp"
#include "opencv2/core/core.hpp"
#include "opencv2/opencv.hpp"
//#include "func_sm.hpp"



void create_adj_mat(const int*klabels,cv::Mat& ad_mat){


	//Image dim sz=height*width
	int height=480;
	int width=640;
	int idx;
	int sp_c,sp_f,sp_b;//Super pixel, current (c),forward (f), bellow (b)
	int n_f,n_b;

	//Adjacency Matrix
	for (int i=0; i<height ; i++){
		for ( int j=0; j<width; j++){
			idx = i*width + j;
			sp_c = klabels[idx];

			if(j<(width-2)){
				n_f =     i*width + (j+1);
				sp_f = klabels[n_f];

				if(sp_f != sp_c){
					//If they are different sp's, then we mark the intersection in t
					//the adjacence matrix
					ad_mat.at<int>(sp_f,sp_c)=1;
					ad_mat.at<int>(sp_c,sp_f)=1;
				}
			}

			if(i<(height-2)){
				n_b = 	  (i+1)*width + j;
				sp_b = klabels[n_b];
				if(sp_b != sp_c){
					//If they are different sp's, then we mark the intersection in t
					//the adjacence matrix
					ad_mat.at<int>(sp_b,sp_c)=1;
					ad_mat.at<int>(sp_c,sp_b)=1;
				}

			}

		}
	}



}
