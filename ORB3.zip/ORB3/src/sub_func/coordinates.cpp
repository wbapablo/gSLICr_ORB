
#include <time.h>
#include <stdio.h>
#include <vector>
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/core/core.hpp"
#include "opencv2/opencv.hpp"

using namespace std;
using namespace cv;

void find_sp_coordinates(const int* klabels,int& im_sz, vector<int>& kxy, vector<vector<int>>& fillmat, Mat img,
		vector<vector<int>>& col_r,
		vector<vector<int>>& col_g,
		vector<vector<int>>& col_b){

	int curr=0;
	int res=0;


	kxy.clear();

	for(int i=0; i<im_sz; i++){

		// curr:: is the current super pixel, and 'i' is its location in the image
		curr=klabels[i];

		//fillmat[curr] is a vector of the super pixel #curr containing the pixels of the super-pixel
		// the element on the middle of fillmat[curr] may be the centroid of the super-pixel

		fillmat[curr].push_back(i);

		//Necesito...vector de vectores. Cada fila contendría
		//la coordenada de todos los pixeles de cada super pixel-->fillmat
		res=i%4;
		if(res==0){

			col_b[curr].push_back(img.at<Vec3b>(i)[0]);
			col_g[curr].push_back(img.at<Vec3b>(i)[1]);
			col_r[curr].push_back(img.at<Vec3b>(i)[2]);
		}


	}

	int tam_fill = fillmat.size();
	int tam_sp;
	int centroid;
	for (int j=1; j<tam_fill;j++){
		tam_sp = (fillmat[j].size())/2;
		centroid = fillmat[j][tam_sp];
		kxy.push_back(centroid);
	}

}


