// Copyright 2014-2015 Isis Innovation Limited and the authors of gSLICr

#include "engines/gSLICr_core_engine.h"
